package main

import (
	_ "monolit/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

